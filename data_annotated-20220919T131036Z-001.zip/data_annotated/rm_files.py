import os

for i in os.listdir():
    splited = i.split('.')
    if int(splited[0]) in range(1,68):
        os.remove(i)